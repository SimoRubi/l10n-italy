from . import models

from openupgradelib import openupgrade
from psycopg2 import sql


def module_migration(cr):
    if openupgrade.is_module_installed(cr, "account_cutoff_start_end_dates"):
        return

    account_cutoff_line_table = "account_cutoff_line"
    if openupgrade.column_exists(cr, account_cutoff_line_table, "prepaid_days"):
        openupgrade.update_module_names(
            cr,
            [
                ("account_cutoff_prepaid", "account_cutoff_start_end_dates"),
            ],
            merge_modules=True,
        )
        openupgrade.logged_query(
            cr,
            sql.SQL(
                """
        ALTER TABLE {0}
            ADD COLUMN IF NOT EXISTS cutoff_days integer
        """
            ).format(
                sql.Identifier(account_cutoff_line_table),
            ),
        )
        openupgrade.logged_query(
            cr,
            sql.SQL(
                """
        update {0}
        set
            cutoff_days = acl.prepaid_days
        from {0} acl
        where
            {0}.id = acl.id;
        """
            ).format(
                sql.Identifier(account_cutoff_line_table),
            ),
        )
