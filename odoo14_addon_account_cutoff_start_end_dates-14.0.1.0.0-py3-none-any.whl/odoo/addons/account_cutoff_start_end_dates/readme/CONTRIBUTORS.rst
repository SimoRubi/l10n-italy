* Alexis de Lattre <alexis.delattre@akretion.com>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Jim Hoefnagels <jim.hoefnagels@dynapps.be>
